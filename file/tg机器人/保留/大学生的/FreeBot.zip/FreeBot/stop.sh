#!/bin/bash
pkill -f "python3 freebot.py"
