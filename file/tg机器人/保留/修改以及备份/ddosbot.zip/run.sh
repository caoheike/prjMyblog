#!/bin/bash
pkill -f "python3 bot.py"
sleep 1
nohup python3 bot.py > bot.log 2>&1 &