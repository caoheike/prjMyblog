#!/bin/bash
pkill -f "python3 bot.py"
