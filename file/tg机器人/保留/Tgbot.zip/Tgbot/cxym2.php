<?php
require('./cURL.php');
use OpensApi\utils\cURL;
$ym = $_GET["ym"];
$icp = cURL::ua('android')->get('http://micp.chinaz.com/?query=' . $ym)->body();
	if(strpos($icp, '未备案或') !== false) {} else {
		if(strpos($icp, '企业')) {
			die('企业');
		} else die('个人');
	}
die('false');