<?php
require('./cURL.php');
use OpensApi\utils\cURL;
$ip = $_GET["ip"];
$domains_body = cURL::ua('android')->get('http://ip.yqie.com/iptodomain.aspx?ip=' . $ip)->body();
$domains = str_Intercept($domains_body, '<table cellspacing="0" class="table width600" style="margin: 0 auto;">', '</table>');
preg_match_all('/<td width=\"90%\" class=\"blue t_l\" style=\"text-align: center\">(.*?)<\/td>/', $domains, $result);
foreach($result[1] as $val) {
	if($val == '域名') continue;
	$icp = cURL::ua('android')->get('http://micp.chinaz.com/?query=' . $val)->body();
	if(strpos($icp, '未备案或') !== false) {} else {
		if(strpos($icp, '企业')) {
			die('企业');
		} else die('个人');
	}
}
die('false');
function str_Intercept($txt1,$q1,$h1) {
	$txt1=strstr($txt1,$q1);
	$cd=strlen($q1);
	$txt1=substr($txt1,$cd);
	$txt1=strstr($txt1,$h1,"TRUE");
	return $txt1;
}
