#pragma once

void telnet_scan_noroot(void);
void telnet_scan_root(void);
void kill_scanners(void);
